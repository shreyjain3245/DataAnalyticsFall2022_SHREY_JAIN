require(rpart)
require(datasets)
library(datasets)
library(rpart.plot)
library(ggplot2)
library(dplyr)
library("ggpubr")
library(stringr)
require(randomForest)
library(cluster)
library(naniar)
library(caret)
library(stats)
library(rstatix)


nyc_data = read.csv("~/Desktop/Fall 22/Data Analytics/Assignment4/NYC_Citywide_Annualized_Calendar_Sales_Update.csv")

View(nyc_data)

# DETERMINE DIFF BETWEEN BOROUGH = QUEENS AND BOROUGH = 4
unique(nyc_data$BOROUGH)

queens = nyc_data[nyc_data$BOROUGH == "QUEENS",]
neigh4 = nyc_data[nyc_data$BOROUGH == "4",]
View(queens)

unique(neigh4$NEIGHBORHOOD)
unique(queens$NEIGHBORHOOD)

str(queens)

min(as.Date(neigh4$SALE.DATE, "%m/%d/%Y")) # 2016-01-01
max(as.Date(neigh4$SALE.DATE, "%m/%d/%Y")) # 2019-12-31
min(as.Date(queens$SALE.DATE, "%m/%d/%Y")) # 2020-01-01
max(as.Date(queens$SALE.DATE, "%m/%d/%Y")) # 2021-12-31

# dataset uses numbers to represent boroughs from 2016-2019 and actual names from 2020-2021
# use combination of both datasets

queens_data = rbind(queens,neigh4)
str(queens_data)
dim(queens_data)
head(queens_data)

help(boxplot)
boxplot(queens_data$SALE.PRICE)
help(hist)
fivenum(queens_data$SALE.PRICE)
queens_data$COMMERCIAL.UNITS[queens_data$SALE.PRICE == max(queens_data$SALE.PRICE)]
hist(queens_data$SALE.PRICE, breaks=50) # so skewed, cannot even make a decent graph

queens_data$SALE.DATE = as.Date(queens_data$SALE.DATE, "%m/%d/%Y") # data cleaning
str(queens_data)
plot(queens_data$SALE.DATE)

ggplot( queens_data , aes( SALE.DATE, SALE.PRICE )) + geom_line() 
ggplot( queens_data , aes( NEIGHBORHOOD, SALE.PRICE )) + geom_line() 

########################################################################
max(queens_data$COMMERCIAL.UNITS, na.rm = TRUE)

model1 = lm(SALE.PRICE ~ RESIDENTIAL.UNITS + COMMERCIAL.UNITS, data = queens_data)
help(plot)
plot(model1, pch=9, col='purple', which=c(4))
cooksDistance = cooks.distance(model1)

sort(round(cooksDistance,5))
max(round(cooksDistance,5))

influential = cooksDistance[(cooksDistance > (3 * mean(cooksDistance, na.rm=TRUE)))]
names_of_influence = names(influential)

influential
length(names_of_influence)

outliers <- queens_data[names_of_influence,]
queens_data_no_outliers = queens_data %>% anti_join(outliers)

model2 = lm(SALE.PRICE ~ RESIDENTIAL.UNITS + COMMERCIAL.UNITS, data=queens_data_no_outliers)
summary(model2)
plot(model2, pch=9, col='red', which=c(4))
cooksDistance2 = cooks.distance(model2)
sort(round(cooksDistance2,5))
max(round(cooksDistance2,5))

num_outliers = length(cooksDistance) - length(cooksDistance2)
num_outliers

summary(cooksDistance)
summary(cooksDistance2)


iqr = fivenum(queens_data$SALE.PRICE)[4] - fivenum(queens_data$SALE.PRICE)[2]
iqr 

lower_bnd = fivenum(queens_data$SALE.PRICE)[2] - (iqr * 1.5)
upper_bnd = fivenum(queens_data$SALE.PRICE)[4] + (iqr * 1.5)

lower_outlier = queens_data$SALE.PRICE[queens_data$SALE.PRICE < lower_bnd]
upper_outlier = queens_data$SALE.PRICE[queens_data$SALE.PRICE > upper_bnd]

lower_bnd
upper_bnd
str(upper_outlier)    


########################################################################
dim(queens_data) # 159220     29
str(queens_data)


# read the documentation for sample() function
help("sample")
##### SAMPLE 1
train = sample(159220,2000)
train

help(as.numeric)
gross_square_feet = as.numeric(str_replace_all(queens_data$GROSS.SQUARE.FEET, "[^[:alnum:]]", ""), na.rm=TRUE)
gross_square_feet
land_square_feet = as.numeric(str_replace_all(queens_data$LAND.SQUARE.FEET, "[^[:alnum:]]", ""), na.rm=TRUE)
land_square_feet

help(lm)
lm.fit <- lm(SALE.PRICE ~ gross_square_feet + land_square_feet, data = queens_data, subset = train)
lm.fit
train

mean((queens_data$SALE.PRICE-predict(lm.fit,queens_data))[-train]^2, na.rm=TRUE)
# Therefore, the estimated test MSE for the linear regression fit is 3.120233e+13

# We can use the poly() function to estimate test error for the quadratic and cubic regression.
# Quadratic regression line
lm.fit2 <- lm(SALE.PRICE~poly(gross_square_feet,2,raw=TRUE) + poly(land_square_feet,2,raw=TRUE), data = queens_data, subset = train) # Quadratic
mean((queens_data$SALE.PRICE-predict(lm.fit2,queens_data))[-train]^2, na.rm=TRUE)
# Therefore, the estimated test MSE for the quadratic regression fit is 9.537597e+14


# Cubic regression line
lm.fit3 <- lm(SALE.PRICE~poly(gross_square_feet,3,raw=TRUE) + poly(land_square_feet,3,raw=TRUE), data = queens_data, subset = train) # Cubic
mean((queens_data$SALE.PRICE-predict(lm.fit3,queens_data))[-train]^2, na.rm=TRUE)
# The error rates are: 3.120233e+13 for linear, 9.537597e+14 for quadratics, and 3.898901e+20 for cubic




#### SAMPLE 2
train = sample(159220,2000)
lm.fit <- lm(SALE.PRICE ~ gross_square_feet + land_square_feet, data = queens_data, subset = train)
mean((queens_data$SALE.PRICE-predict(lm.fit,queens_data))[-train]^2, na.rm=TRUE)
# Therefore, the estimated test MSE for the linear regression fit is 1.761347e+13

# We can use the poly() function to estimate test error for the quadratic and cubic regression.
# Quadratic regression line
lm.fit2 <- lm(SALE.PRICE~poly(gross_square_feet,2,raw=TRUE) + poly(land_square_feet,2,raw=TRUE), data = queens_data, subset = train) # Quadratic
mean((queens_data$SALE.PRICE-predict(lm.fit2,queens_data))[-train]^2, na.rm=TRUE)
# Therefore, the estimated test MSE for the quadratic regression fit is 4.905586e+14


# Cubic regression line
lm.fit3 <- lm(SALE.PRICE~poly(gross_square_feet,3,raw=TRUE) + poly(land_square_feet,3,raw=TRUE), data = queens_data, subset = train) # Cubic
mean((queens_data$SALE.PRICE-predict(lm.fit3,queens_data))[-train]^2, na.rm=TRUE)
# The error rates are: 1.761347e+13 for linear, 4.905586e+14 for quadratics, and 1.007761e+19 for cubic






#### SAMPLE 3
train = sample(159220,2000)
lm.fit <- lm(SALE.PRICE ~ gross_square_feet + land_square_feet, data = queens_data, subset = train)
mean((queens_data$SALE.PRICE-predict(lm.fit,queens_data))[-train]^2, na.rm=TRUE)
# Therefore, the estimated test MSE for the linear regression fit is 1.727466e+13

# We can use the poly() function to estimate test error for the quadratic and cubic regression.
# Quadratic regression line
lm.fit2 <- lm(SALE.PRICE~poly(gross_square_feet,2,raw=TRUE) + poly(land_square_feet,2,raw=TRUE), data = queens_data, subset = train) # Quadratic
mean((queens_data$SALE.PRICE-predict(lm.fit2,queens_data))[-train]^2, na.rm=TRUE)
# Therefore, the estimated test MSE for the quadratic regression fit is 4.143708e+14


# Cubic regression line
lm.fit3 <- lm(SALE.PRICE~poly(gross_square_feet,3,raw=TRUE) + poly(land_square_feet,3,raw=TRUE), data = queens_data, subset = train) # Cubic
mean((queens_data$SALE.PRICE-predict(lm.fit3,queens_data))[-train]^2, na.rm=TRUE)
# The error rates are: 1.727466e+13 for linear, 4.143708e+14 for quadratics, and 6.314617e+16 for cubic




################


str(queens_data)

# kmeans clustering
# Read the documentation for kmeans() function
# https://stat.ethz.ch/R-manual/R-devel/library/stats/html/kmeans.html
k.max <- 20

length(unique(queens_data$NEIGHBORHOOD))
ggplot(queens_data,aes(x = Longitude, y = Latitude, col = NEIGHBORHOOD)) + geom_point()


# iter.max = the maximum number of iterations allowed
# nstart = if centers is a number, how many random sets should be chosen.
queens_data[c(22,23,2)]
# help(kmeans)
neighborhoodClusters <- kmeans(na.omit(queens_data[c(22,23)]), length(unique(queens_data$NEIGHBORHOOD)), iter.max=50, nstart = 20) # nstart is the number of random start
str(neighborhoodClusters)

clusplot(na.omit(queens_data[,c(22,23,2)]),neighborhoodClusters$cluster, color = TRUE, shade = TRUE, labels = 0, lines = 0)
summary(neighborhoodClusters)

neighborhoodClusters # sum of squares: 98.9 %

###################

length(neighborhoodClusters$cluster)
length(queens_data$NEIGHBORHOOD[!is.na(queens_data$Latitude) & !is.na(queens_data$Longitude)])

cm = table(queens_data$NEIGHBORHOOD[!is.na(queens_data$Latitude) & !is.na(queens_data$Longitude)], neighborhoodClusters$cluster)
cm

View(cm)

write.csv(cm,"~/Desktop/Fall 22/Data Analytics/Assignment4/CongtingencyTable.csv")

queens_data[queens_data$NEIGHBORHOOD == "AIRPORT JFK",]


###############

unique_neighborhoods = unique(queens_data$NEIGHBORHOOD)
neighborhood_numvals = queens_data$NEIGHBORHOOD

for (x in 1:length(unique_neighborhoods)) {
  neighborhood_numvals[neighborhood_numvals == unique_neighborhoods[x]] = x
}

neighborhood_numvals = as.numeric(neighborhood_numvals)
str(neighborhood_numvals)
str(queens_data$Latitude)
max(neighborhood_numvals)

help(cor_test)

chisq.test(cm, correct = FALSE) # p-value < 2.2e-16

cor.test(queens_data$Latitude, neighborhood_numvals) # p-value < 2.2e-16
cor.test(queens_data$Longitude, neighborhood_numvals) # p-value < 2.2e-16
cor.test(queens_data$Latitude, queens_data$Longitude) # p-value < 2.2e-16

